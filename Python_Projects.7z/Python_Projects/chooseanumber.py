from random import randint
from random import shuffle
fake_nums = {}


real_num = randint(0, 999)


def gen_a_number(range):
    for x in range(range):
        globals()[f"fake_num{x}"] = x + 1


fake_num1 = randint(0, 999)
fake_num2 = randint(0, 999)


def check_if_regen_needed(excluded_number, *args):
    result = []
    for nums in args:
        if nums == excluded_number:
            nums = randint(0, 999)
        result.append(nums)
    return result


fake_num1, fake_num2 = check_if_regen_needed(real_num, fake_num1, fake_num2)

items = [fake_num1, fake_num2, real_num]
shuffle(items)
number_inp = input(f"choose a number from these {
                   ', '.join(map(str, items))}: ")
if str(number_inp) == str(real_num):
    print("u guessed a correct number")
else:
    print('wrong u should kys now!!!!!')
