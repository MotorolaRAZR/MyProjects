import hashlib
import pathlib
import os
import sqlite3


def password_form():
    string = input("think of a password: ")
    utf8_string = string.encode()
    passwd = hashlib.sha256(utf8_string).hexdigest()
    hashf = open("hash.txt", "w")
    hashf.write(passwd)

    return hashf


def login_form():
    logininp = input("type your password: ")
    encodedlogininp = logininp.encode()
    logininpwd = hashlib.sha256(encodedlogininp).hexdigest()

    return logininpwd


if pathlib.Path("hash.txt").is_file():
    print("cool file exists running another checks!!")
if os.stat("hash.txt").st_size == 0:
    print("file exists but empty, bringing up a register form")
    password_form()
if pathlib.Path("hash.txt").is_file() is False:
    print("no password")
    password_form()

readpwdf = open("hash.txt", "r")
if login_form() == readpwdf.read():
    print('success')
else:
    print('not a success')
