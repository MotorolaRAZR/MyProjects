while True:
    numbers_to_add = input("write a numbers to add: ")
    numbers_to_mult = input("write number u want to multiply: ")
    list_to_sum = list(numbers_to_add.split(" "))

    def multiply(*args):
        multiplied_number = 1
        for numbers in args:
            multiplied_number *= numbers
        return multiplied_number

    numbers = [int(nums) for nums in numbers_to_mult.split()]
# formatted_input = [int(d) for d in list_to_sum]
    print(sum(map(int, list_to_sum)))
# print(multiply(formatted_input))
    print(multiply(*numbers))
