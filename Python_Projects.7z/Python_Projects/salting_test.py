
import hashlib
import os

# Function to hash a password with a salt


def hash_password(password):
    salt = os.urandom(16)  # Generate a random 16-byte salt
    salted_password = salt + password.encode()  # Combine salt with the password
    hashed_password = hashlib.sha256(salted_password).hexdigest()  # Hash it
    return salt, hashed_password

# Function to verify a password


def verify_password(stored_salt, stored_hash, password_attempt):
    # Combine salt with input attempt
    salted_attempt = stored_salt + password_attempt.encode()
    attempt_hash = hashlib.sha256(salted_attempt).hexdigest()  # Hash it
    return attempt_hash == stored_hash  # Compare hashes


# Example usage
# Storing password
password = input("type something: ")
salt, hashed_password = hash_password(password)
print(f"Salt (hex): {salt.hex()}")
print(f"Hashed Password: {hashed_password}")

# Verifying password
password_attempt = "1234"  # Try the correct password
is_correct = verify_password(salt, hashed_password, password_attempt)
print(f"Password is correct: {is_correct}")

password_attempt = "12345"  # Try an incorrect password
is_correct = verify_password(salt, hashed_password, password_attempt)
print(f"Password is correct: {is_correct}")
