while True:  # ради интереса сделал выбор в цикле который не закончится пока не будет ввод нуля или единицы
    a = input("0выкл/1вкл: ")
    if a == "0":
        print("passed")
        break
    elif a == "1":
        print("passed")
        break
    else:
        print("некорекктный вариант ответа")
