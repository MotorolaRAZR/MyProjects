import sqlite3

db = sqlite3.connect('users.db')
cursor = db.cursor()
cursor.execute(
    "CREATE TABLE IF NOT EXISTS logins(name text, password blob, salt blob)")
cursor.execute(
    "INSERT INTO logins VALUES('grimax', 'sigmapasswordtest', '1337L24:tgd9')")
