
def number_to_russian(number):
    units = ["", "один", "два", "три", "четыре",
             "пять", "шесть", "семь", "восемь", "девять"]
    teens = ["десять", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать",
             "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать"]
    tens = ["", "", "двадцать", "тридцать", "сорок", "пятьдесят",
            "шестьдесят", "семьдесят", "восемьдесят", "девяносто"]
    hundreds = ["", "сто", "двести", "триста", "четыреста",
                "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот"]
    thousands = ["", "одна тысяча", "две тысячи"] + \
        [units[i] + " тысяч(и)" for i in range(3, 10)]

    if number == 0:
        return "ноль"

    result = []

    if number >= 10000:
        if 10 <= (number // 1000) < 20:
            result.append(teens[(number // 1000) - 10] + " тысяч")
        else:
            result.append(tens[number // 10000] + " " +
                          units[(number // 1000) % 10] + " тысяч")
        number %= 1000
    elif number >= 1000:
        result.append(thousands[number // 1000])
        number %= 1000

    if number >= 100:
        result.append(hundreds[number // 100])
        number %= 100

    if 10 <= number < 20:
        result.append(teens[number - 10])
    else:
        if number >= 20:
            result.append(tens[number // 10])
            number %= 10
        if number > 0:
            result.append(units[number])

    return " ".join(result).strip()


# Test the program
num = int(input("Enter a number: "))
print(number_to_russian(num))
