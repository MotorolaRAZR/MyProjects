def is_parameter_in_boot_option(param):
    try:
        with open("/proc/cmdline", "r") as f:
            cmdline = f.read()
            return param in cmdline
    except FileNotFoundError:
        print(
            "The /proc/cmdline file was not found. Are you running this on a Linux system?")
        return False


# Usage
if is_parameter_in_boot_option("ec_sys"):
    print("'ec_sys' is in the boot options.")
else:
    print("'ec_sys' is not in the boot options.")
