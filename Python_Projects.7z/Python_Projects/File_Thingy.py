file_name = input("введи название файла: ")
print("что ты хочешь туда накалякать, напиши exit/выйти что бы закрыть программу: ")
while True:
    file_write = input("")
    if file_write.lower() in ["exit", "выйти"]:
        break

    with open(f"{file_name}.txt", "w") as file:
        file.write(file_write)
