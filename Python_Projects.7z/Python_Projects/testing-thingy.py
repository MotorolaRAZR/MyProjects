try:
    to_code = int(input("type a number: "))
except ValueError:
    print("not a number u idiot!!!!!!")
