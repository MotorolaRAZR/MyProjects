-- bootstrap lazy.nvim, LazyVim and your plugins
if vim.g.neovide then
  vim.g.neovide_padding_top = 32
  vim.g.neovide_padding_bottom = 32
  vim.g.neovide_padding_right = 32
  vim.g.neovide_padding_left = 32
  vim.g.neovide_scale_factor = 1
end
require("config.lazy")
require("overseer").setup()
require("mason").setup()
require("mason-lspconfig").setup()
require("toggleterm").setup({
  shading_factor = "0",
})
