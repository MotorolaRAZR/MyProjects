return {
  -- amongst your other plugins
  {
    "akinsho/toggleterm.nvim",
    keys = {
      { "<leader>t", "<cmd>ToggleTerm<cr>" },
    },
    version = "*",
    config = true,
  },
}
