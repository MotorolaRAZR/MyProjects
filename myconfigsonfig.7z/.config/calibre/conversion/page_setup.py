json:{
  "output_profile": "generic_eink"
}